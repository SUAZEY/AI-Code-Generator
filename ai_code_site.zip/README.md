# AI Code Generator

This is a free website to generate games and websites using AI.

## How to Deploy

1. Upload this folder to a GitHub repository.
2. Go to repository settings.
3. Scroll to 'Pages', select the main branch, and set `/` as the folder.
4. Click 'Save' and your website will be live!
